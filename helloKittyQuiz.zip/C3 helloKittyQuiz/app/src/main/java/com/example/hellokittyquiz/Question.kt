package com.example.hellokittyquiz

data class Question (val textResId:Int, val answer: Boolean, var attempt: Boolean){

}